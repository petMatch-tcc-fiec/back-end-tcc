package com.example.registros.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    Long id;

    String nomeOng;
    String emailOng;
    String telefone;
    String cnpj;
    String endereco;

    // 🔑 Campo de senha
    String senha;
}
