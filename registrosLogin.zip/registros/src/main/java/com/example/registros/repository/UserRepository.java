package com.example.registros.repository;

import com.example.registros.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    // método automático do Spring Data JPA
    User findByEmailOng(String emailOng);
}
