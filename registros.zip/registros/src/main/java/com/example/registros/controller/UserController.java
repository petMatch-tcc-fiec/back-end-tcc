package com.example.registros.controller;

import com.example.registros.entity.User;
import com.example.registros.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")

public class UserController {

    private UserService userService;

    public UserController(UserService userService){
        this.userService = userService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // do REST, o post cria, logo a resposta padrao eh 201(created)
    User criaUser(@RequestBody User novoUser){
        User userCriado = this.userService.criaUser(novoUser);
        return userCriado;
    }
    @GetMapping
    @ResponseStatus(HttpStatus.OK) // do REST, o get recebe, logo a resposta padrao eh 200(ok)
    List<User> retornaUsersDoBanco(){
        List<User> usersNoBanco = this.userService.pegaUsers();
        return usersNoBanco;
    }

    @DeleteMapping
    @RequestMapping("/{id}")
    @ResponseStatus(HttpStatus.ACCEPTED)
    void deletaUser(@PathVariable("id") Long idDoUser){
        this.userService.deletaUser(idDoUser);
    }

    @DeleteMapping ("/todos")
    @ResponseStatus(HttpStatus.ACCEPTED)
    void deletaUsers(){
        this.userService.deletaUsers();
    }
}