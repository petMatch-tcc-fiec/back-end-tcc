package com.example.registros.service;

import com.example.registros.entity.User;
import java.util.List;

public interface UserService {
    User criaUser(User novoUser);
    List<User> pegaUsers();
    void deletaUser(Long idDoUser);
    void deletaUsers();
}