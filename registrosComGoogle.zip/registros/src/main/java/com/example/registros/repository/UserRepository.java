package com.example.registros.repository;

import com.example.registros.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    // Retorno Optional evita null e facilita uso com .orElse()
    Optional<User> findByEmailOng(String emailOng);
}
