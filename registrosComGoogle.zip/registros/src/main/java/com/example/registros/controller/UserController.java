package com.example.registros.controller;

import com.example.registros.entity.User;
import com.example.registros.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private UserService userService;

    public UserController(UserService userService){
        this.userService = userService;
    }

    // Cadastro
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    User criaUser(@RequestBody User novoUser){
        return this.userService.criaUser(novoUser);
    }

    // Listar todos
    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    List<User> retornaUsersDoBanco(){
        return this.userService.pegaUsers();
    }

    // Deletar por id
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.ACCEPTED)
    void deletaUser(@PathVariable("id") Long idDoUser){
        this.userService.deletaUser(idDoUser);
    }

    // Deletar todos
    @DeleteMapping("/todos")
    @ResponseStatus(HttpStatus.ACCEPTED)
    void deletaUsers(){
        this.userService.deletaUsers();
    }

    // 🔑 Login
    @PostMapping("/login")
    @ResponseStatus(HttpStatus.OK)
    public User login(@RequestBody User loginRequest) {
        User user = this.userService.autenticaUser(loginRequest.getEmailOng(), loginRequest.getSenha());
        if (user == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Email ou senha inválidos");
        }
        return user;
    }
}
