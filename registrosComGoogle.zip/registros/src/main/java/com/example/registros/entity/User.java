package com.example.registros.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String nomeOng;
    private String nomeFantasiaOng;  // novo
    private String razaoSocialOng;   // novo
    private String emailOng;
    private String telefone;
    private String cnpj;
    private String endereco;
    private String contatoOng;        // novo

    // 🔑 Campo de senha
    private String senha;
}