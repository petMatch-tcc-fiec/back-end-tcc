package com.example.registros.service.impl;

import com.example.registros.entity.User;
import com.example.registros.repository.UserRepository;
import com.example.registros.service.UserService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository){
        this.userRepository = userRepository;
    }

    @Override
    public User criaUser(User novoUser) {
        // Aqui você poderia adicionar validações extras (CNPJ, email, etc.)
        return this.userRepository.save(novoUser);
    }

    @Override
    public List<User> pegaUsers() {
        return this.userRepository.findAll();
    }

    @Override
    public void deletaUser(Long idDoUser) {
        if (userRepository.existsById(idDoUser)) {
            this.userRepository.deleteById(idDoUser);
        }
    }

    @Override
    public void deletaUsers() {
        this.userRepository.deleteAll();
    }

    @Override
    public User autenticaUser(String emailOng, String senha) {
        // Login simples: busca por email e compara senha em texto puro
        User user = userRepository.findByEmailOng(emailOng).orElse(null);
        if (user != null && user.getSenha().equals(senha)) {
            return user;
        }
        return null;
    }
}